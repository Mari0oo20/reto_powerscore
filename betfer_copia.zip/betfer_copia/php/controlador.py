from wsgiref.simple_server import make_server
from urllib.parse import parse_qs
import vistas
import modelos

def mostrarPartidos():
    sesion = modelos.abrir_sesion()
  
    partidos = sesion.query(modelos.Partidos).all()
 
    modelos.cerrar_sesion(sesion)
    return partidos

def mostrarPartidosDiarios():
    sesion = modelos.abrir_sesion()
  
    from datetime import date
 
    partidos_diarios = sesion.query(modelos.Partidos).filter(modelos.Partidos.date == date.today()).all()
 
    modelos.cerrar_sesion(sesion)
    return partidos_diarios


def add_product(environ, start_response):
    if environ['REQUEST_METHOD'] == 'POST':
        try:
            # Leer y parsear los datos del formulario
            # size 0 si la cabecera CONTENT_LENGTH no está definida
            size = int(environ.get('CONTENT_LENGTH', 0))
            # convertir en cadena de texto
            data = environ['wsgi.input'].read(size).decode()
            params = parse_qs(data) # diccionario con clave y valor (lista, aunque sólo haya un valor)            
            # Crear y guardar el nuevo producto
            producto = modelos.Producto(
                producto=params['producto'][0],
                modelo=params['modelo'][0],
                precio=float(params['precio'][0])
            )
            sesion = modelos.abrir_sesion()
            producto.create(sesion)
            modelos.cerrar_sesion(sesion)
            sesion = None
            # Redirigir a la página principal
            # '303 See Other' indica que se debe realizar una solicitud GET a la 
            # URL especificada en Location, en este caso -> '/es'
            start_response('303 See Other', [('Location', '/es')])
            # hay que devolver cadena de bytes
            return [b''] # cuerpo de la respuesta vacío porque no necesitamos enviar contenido adicional
            # finaliza la respuesta, permitiendo que el navegador procese la redirección hacia '/es'
        except Exception as e:
            start_response('500 Internal Server Error', [('Content-type', 'text/plain')])
            return [str(e).encode('utf-8')]
    else:
        return vistas.handle_404(environ, start_response)


# Definir la función app que manejará las solicitudes.
def app(environ, start_response):
    path = environ.get('PATH_INFO')
    # print('path: ', path)
    if path == '/':
        return vistas.english_handle_index(environ, start_response)
    
    elif path == '/es':
        partidos = mostrarPartidos()
        return vistas.spanish_handle_index(environ, start_response, partidos)
    
    elif path == '/index.html':
        partidosDiarios = mostrarPartidosDiarios()
        return vistas.mostrar_index(environ, start_response, partidosDiarios)
    
    elif path == '/partidos.html':
        partidos = mostrarPartidos()
        return vistas.mostrar_partidos(environ, start_response, partidos)
    
    elif path == '/perfil.html':
        partidos = mostrarPartidos()
        return vistas.mostrar_perfil(environ, start_response, partidos)
    
    elif path == '/ajustes.html':
        partidos = mostrarPartidos()
        return vistas.mostrar_ajustes(environ, start_response, partidos)
    
    elif path == '/informacion.html':
        partidos = mostrarPartidos()
        return vistas.mostrar_informacion(environ, start_response, partidos)
    
    elif path == '/registro.html':
        partidos = mostrarPartidos()
        return vistas.mostrar_registro(environ, start_response, partidos)
    
    elif path == '/sesion.html':
        partidos = mostrarPartidos()
        return vistas.mostrar_sesion(environ, start_response, partidos)
    
    elif path == '/add_product':
        return add_product(environ, start_response)
    
    elif path.startswith('/static/'):
        return vistas.serve_static(environ, start_response)
    
    elif path == '/index.html':
        partidos = mostrarPartidos()
        return vistas.mostrar_index(environ, start_response, partidos)

    
    else:
        return vistas.handle_404(environ, start_response)


if __name__ == "__main__":
    host = 'localhost'
    port = 8000

    httpd = make_server(host, port, app)
    print(f"Servidor en http://{host}:{port}")
    httpd.serve_forever()


'''
Una vez ejecutado el controlador, podemos acceder a través del navegador, 
con las rutas: http://localhost:8000/    (no se usa jinja2)

Si se pone una url diferente, saldrá el mensaje de 'página no encontrada'
'''