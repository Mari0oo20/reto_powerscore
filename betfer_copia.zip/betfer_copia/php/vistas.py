from jinja2 import Environment, FileSystemLoader
import os

# Obtén el directorio actual donde se encuentra el script
current_dir = os.path.dirname(os.path.abspath(__file__))
templates_dir = os.path.join(current_dir, 'templates')

# Cargar las plantillas desde el directorio 'templates'
env = Environment(loader=FileSystemLoader(templates_dir))

# Obtener la plantilla 'index.html'
template = env.get_template('index.html')
template_dos = env.get_template('partidos.html')
template_tres = env.get_template('perfil.html')
template_cuatro = env.get_template('ajustes.html')
template_cinco = env.get_template('informacion.html')
template_seis = env.get_template('registro.html')
template_siete = env.get_template('sesion.html')

def mostrar_index(environ, start_response, partidosDiarios):
    response = template.render(partidosDiarios=partidosDiarios).encode('utf- 8')
    status = '200 OK'
    response_headers = [('Content-type', 'text/html')]
    start_response(status, response_headers)
    return [response]

def mostrar_partidos(environ, start_response, partidos):
    response = template_dos.render(partidos=partidos).encode('utf- 8')
    status = '200 OK'
    response_headers = [('Content-type', 'text/html')]
    start_response(status, response_headers)
    return [response]

def mostrar_perfil(environ, start_response, partidos):
    response = template_tres.render(partidos=partidos).encode('utf- 8')
    status = '200 OK'
    response_headers = [('Content-type', 'text/html')]
    start_response(status, response_headers)
    return [response]

def mostrar_ajustes(environ, start_response, partidos):
    response = template_cuatro.render(partidos=partidos).encode('utf- 8')
    status = '200 OK'
    response_headers = [('Content-type', 'text/html')]
    start_response(status, response_headers)
    return [response]

def mostrar_informacion(environ, start_response, partidos):
    response = template_cinco.render(partidos=partidos).encode('utf- 8')
    status = '200 OK'
    response_headers = [('Content-type', 'text/html')]
    start_response(status, response_headers)
    return [response]

def mostrar_registro(environ, start_response, partidos):
    response = template_seis.render(partidos=partidos).encode('utf- 8')
    status = '200 OK'
    response_headers = [('Content-type', 'text/html')]
    start_response(status, response_headers)
    return [response]

def mostrar_sesion(environ, start_response, partidos):
    response = template_siete.render(partidos=partidos).encode('utf- 8')
    status = '200 OK'
    response_headers = [('Content-type', 'text/html')]
    start_response(status, response_headers)
    return [response]




def handle_404(environ, start_response):
    # Lógica para manejar una ruta no reconocida (404)
    status = '404 Not Found'
    response_headers = [('Content-type', 'text/html')]
    start_response(status, response_headers)
    return [b'Page not found']

# Función para servir archivos estáticos
def serve_static(environ, start_response):     
    static_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'static'))
    print('static_dir', static_dir)
    #static_dir c:\*\*\DWES\Ej_mvc\static
    path = environ['PATH_INFO']
    print('path is:', path) 
    # path is: /static/style.css    
    css_path = static_dir + '\\style.css'    
    print('css_path:', css_path)
    #css_path: c:\*\*\DWES\Ej_mvc\static\style.css
    
    if not path.startswith('/static/'):
        start_response('404 Not Found', [('Content-type', 'text/plain')])
        return [b'Not Found']
    else:
        # Serve the file
        try:
            with open(css_path, 'rb') as file:
                cssFile = file.read()
                start_response('200 OK', [('Content-type', 'text/css')]) 
                return [cssFile]            
        except Exception as e:
            start_response('500 Internal Server Error', [('Content-type', 'text/plain')])
            return [str(e).encode('utf-8')]
        

