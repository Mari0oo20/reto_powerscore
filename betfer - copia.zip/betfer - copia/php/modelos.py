from sqlalchemy import create_engine, Column, Integer, DateTime, String, Float
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.ext.declarative import declarative_base


# Configuración de la base de datos
DATABASE_URL = "postgresql://andoni:andoni@localhost:5433/reto"
engine = create_engine(DATABASE_URL)

# Crear una sesión para interactuar con la base de datos
Session = sessionmaker(bind=engine)

# Funciones para gestionar la sesión
def abrir_sesion():
    return Session()

def cerrar_sesion(session):
    session.close()


from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()
# Clase base para el CRUD
class miCRUD:
    def create(self, session):
        session.add(self)
        session.commit()

    @classmethod
    def read(cls, session, **consulta):
        return session.query(cls).filter_by(**consulta).all()

    def update(self, session):
        session.commit()

    def delete(self, session):
        session.delete(self)
        session.commit()


def imagenes(session):
    session.close()


class Partidos(Base, miCRUD):
    __tablename__ = 'partidos'
    idPartidos = Column(Integer, primary_key=True)
    round = Column(String)
    date = Column(DateTime)
    team_1 = Column(String)
    team_2 = Column(String)
    ft_team1 = Column(Integer)
    ft_team2 = Column(Integer)

class Equipos(Base, miCRUD):
    __tablename__ = 'equipos'
    idEquipos = Column(Integer, primary_key=True)
    idUsuarios = Column(Integer, ForeignKey('usuarios.idUsuarios'))
    nombre = Column(String)
    logo = Column(String)

    # Relación opcional para facilitar el acceso a los datos del usuario relacionado
    usuario = relationship("Usuarios", back_populates="equipos")

class Usuarios(Base, miCRUD):
    __tablename__ = 'usuarios'
    idUsuarios = Column(Integer, primary_key=True)
    nombre = Column(String)
    correo = Column(String)
    contrasena = Column(String)

    # Relación opcional para definir la relación inversa
    equipos = relationship("Equipos", back_populates="usuario")



# Crear las tablas en la base de datos (esto solo se hace una vez)
Base.metadata.create_all(engine)




# API en la base de datos

import requests
from datetime import datetime
def insertar_partidos_en_base_de_datos():
    url = "https://raw.githubusercontent.com/openfootball/football.json/refs/heads/master/2024-25/es.1.json"
    
    
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
    

        # Acceder a la lista de partidos
        partidos = data["matches"]
        
        # Abrir una sesión de base de datos
        sesion = abrir_sesion()

        # Bucle para recorrer todos los partidos y agregar a la base de datos
        for partido in partidos:
            ft_team1 = partido["score"].get("ft", [0, 0])[0] if "score" in partido else 0
            ft_team2 = partido["score"].get("ft", [0, 0])[1] if "score" in partido else 0

            nuevo_partido = Partidos (
                round=partido["round"],
                date=partido["date"],
                team_1=partido["team1"],
                team_2=partido["team2"],
                ft_team1=ft_team1,
                ft_team2=ft_team2
            )
            
            # Añadir partido a la base de datos
            sesion.add(nuevo_partido)

        # Confirmar todos los cambios en la base de datos
        sesion.commit()
        
        print("Todos los datos de los partidos fueron insertados correctamente.")

    else:
        print(f"Error en la solicitud. Código de estado: {response.status_code}")

'''
insertar_partidos_en_base_de_datos()
'''


def insertar_equipos():
    sesion = abrir_sesion()

    # Diccionario de datos para los equipos y sus logos, junto con un idUsuarios para la FK
    equipos_data = {
        "FC Barcelona": ("https://ssl.gstatic.com/onebox/media/sports/logos/paYnEE8hcrP96neHRNofhQ_48x48.png", 1),
        "Real Madrid CF": ("https://ssl.gstatic.com/onebox/media/sports/logos/Th4fAVAZeCJWRcKoLW7koA_48x48.png", 2),
        "Club Atlético de Madrid": ("https://ssl.gstatic.com/onebox/media/sports/logos/pEqmA7CL-VRo4Llq3rwIPA_48x48.png", 3),
        "Villarreal CF": ("https://ssl.gstatic.com/onebox/media/sports/logos/WKH7Ak5cYD6Qm1EEqXzmVw_48x48.png", 4),
        "CA Osasuna": ("https://ssl.gstatic.com/onebox/media/sports/logos/pk-hNCNpGM_JDoHHvLVF-Q_48x48.png", 5),
        "Athletic Club": ("https://ssl.gstatic.com/onebox/media/sports/logos/OSL_5Zm6kYPP1J17Bo5uDA_48x48.png", 6),
        "Real Betis Balompié": ("https://ssl.gstatic.com/onebox/media/sports/logos/XDClkrMKtkm3UTP2YKN6oQ_48x48.png", 7),
        "RCD Mallorca": ("https://ssl.gstatic.com/onebox/media/sports/logos/Ss21P4CUmigjrEtcoapjVg_48x48.png", 8),
        "Rayo Vallecano de Madrid": ("https://ssl.gstatic.com/onebox/media/sports/logos/i5LifmxEVIl0sbvIysiyhw_48x48.png", 9),
        "RC Celta de Vigo": ("https://ssl.gstatic.com/onebox/media/sports/logos/wpdhixHP_sloegfP0UlwAw_48x48.png", 10),
        "Real Sociedad de Fútbol": ("https://ssl.gstatic.com/onebox/media/sports/logos/w8tb1aeBfVZIj9tZXf7eZg_48x48.png", 11),
        "Girona FC": ("https://ssl.gstatic.com/onebox/media/sports/logos/sHiSmLm_rA0BOC5MfrNt8A_48x48.png", 12),
        "Sevilla FC": ("https://ssl.gstatic.com/onebox/media/sports/logos/hCTs5EX3WjCMC5Jl3QE4Rw_48x48.png", 13),
        "Deportivo Alavés": ("https://ssl.gstatic.com/onebox/media/sports/logos/meAnutdPID67rfUecKaoFg_48x48.png", 14),
        "CD Leganés": ("https://ssl.gstatic.com/onebox/media/sports/logos/Id84F7Ji9rZGVacaazlBYA_48x48.png", 15),
        "Getafe CF": ("https://ssl.gstatic.com/onebox/media/sports/logos/1UDHZMdKZD15W5gus7dJyg_48x48.png", 16),
        "RCD Espanyol de Barcelona": ("https://ssl.gstatic.com/onebox/media/sports/logos/TKitIqelDyN6M-kYt4Uc0g_48x48.png",17),
        "UD Las Palmas": ("https://ssl.gstatic.com/onebox/media/sports/logos/yOIfuEFVFzu1dD8HiJt9vA_48x48.png", 18),
        "Real Valladolid CF": ("https://ssl.gstatic.com/onebox/media/sports/logos/DdERt3jquzbYD95zvHQJWw_48x48.png", 19),
        "Valencia CF": ("https://ssl.gstatic.com/onebox/media/sports/logos/QPbjvDwI_0Wuu4tCS2O6uw_48x48.png", 20)
    }

    # Bucle para recorrer todos los equipos y agregar a la base de datos
    for nombre, datos in equipos_data.items():
        logo, id_usuario = datos  # Aquí extraemos el logo y el id_usuario correctamente
        
        nuevo_equipo = Equipos(
            nombre=nombre,
            logo=logo,
            idUsuarios=id_usuario  # Asignamos la FK `idUsuarios`
        )
        
        sesion.add(nuevo_equipo)

    sesion.commit()
    
    print("Todos los datos de los equipos fueron insertados correctamente.")
